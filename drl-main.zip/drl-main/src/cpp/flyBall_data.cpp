#include "flyBall.h"

flyBall::P_flyBall_T flyBall::flyBall_P{

  0.0,

  7.0,

  -30.0,

  0.0
};
